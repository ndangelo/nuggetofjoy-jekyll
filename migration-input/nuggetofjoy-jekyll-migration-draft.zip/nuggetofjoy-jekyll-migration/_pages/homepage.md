---
title: "HOMEPAGE"
date: "2025-12-12 10:55:20"
layout: page
permalink: "/homepage/"
categories: []
tags: []
wordpress_id: "67762"
---

<style>
500&family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:ital,wght@0,500;0,600;1,500;1,600&display=swap');

:root {
  --ink: #20211f;
  --muted: #666862;
  --paper: #f8f7f3;
  --line: #deded6;
  --accent: #d3f36b;
  --mono: "SFMono-Regular", Consolas, "Liberation Mono", monospace;
  --sans: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
  --serif: Georgia, "Times New Roman", serif;
}
* { box-sizing: border-box; }
html { scroll-behavior: smooth; }
body { margin: 0; color: var(--ink); background: var(--paper); font-family: var(--sans); line-height: 1.55; }
a { color: inherit; }
.skip-link { position: absolute; top: -50px; left: 1rem; padding: .7rem 1rem; background: var(--accent); z-index: 10; }
.skip-link:focus { top: 1rem; }
.site-header { min-height: 82px; display: flex; align-items: center; justify-content: space-between; gap: 2rem; padding: 1rem clamp(1.25rem, 5vw, 5rem); border-bottom: 1px solid var(--line); }
.wordmark { font-weight: 700; font-size: 1.35rem; letter-spacing: -.07em; text-decoration: none; white-space: nowrap; }
.wordmark span:first-child { font-family: var(--serif); font-style: italic; font-weight: 500; margin: 0 .1em; }
.wordmark .dot { color: #7d9d1d; }
nav { display: flex; flex-wrap: wrap; gap: clamp(1rem, 3vw, 2.5rem); }
nav a { font-size: .86rem; text-decoration: none; }
nav a:hover, .text-link:hover { text-decoration-thickness: 2px; text-underline-offset: 4px; text-decoration: underline; }
.hero { position: relative; overflow: hidden; min-height: 470px; padding: clamp(4rem, 9vw, 8rem) clamp(1.25rem, 10vw, 10rem) 5rem; border-bottom: 1px solid var(--line); }
.eyebrow { font: 500 .7rem/1.4 var(--mono); letter-spacing: .12em; text-transform: uppercase; color: var(--muted); }
.hero h1 { position: relative; z-index: 1; max-width: 850px; margin: 1.2rem 0; font-size: clamp(3.2rem, 8vw, 7.2rem); line-height: .99; letter-spacing: -.075em; font-weight: 600; }
.hero h1 em { font-family: var(--serif); font-weight: 500; letter-spacing: -.065em; }
.intro { max-width: 490px; font-size: 1.1rem; color: var(--muted); }
.text-link { display: inline-block; margin-top: 1.4rem; font-weight: 600; text-decoration: none; border-bottom: 1px solid var(--ink); padding-bottom: .3rem; }
.hero-mark { position: absolute; right: 7%; bottom: -3.5rem; color: #eeede6; font-size: clamp(10rem, 26vw, 25rem); line-height: 1; letter-spacing: -.13em; font-weight: 700; pointer-events: none; }
.hero-mark span { font-family: var(--serif); font-style: italic; }
.resource-section { padding: clamp(4rem, 8vw, 7rem) clamp(1.25rem, 7vw, 7rem); }
.section-heading { display: flex; align-items: end; justify-content: space-between; gap: 2rem; margin-bottom: 2rem; }
h2 { margin: .4rem 0 0; font-size: clamp(2.1rem, 4vw, 3.7rem); line-height: 1.05; letter-spacing: -.06em; }
.card-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 1rem; }
.resource-card { min-height: 280px; position: relative; display: flex; flex-direction: column; align-items: flex-start; padding: clamp(1.4rem, 3vw, 2.5rem); text-decoration: none; transition: transform .18s ease; }
.resource-card:hover { transform: translateY(-4px); }
.card-sand { background: #ece7db; }
.card-blue { background: #dce8ee; }
.card-green { background: #e1e8d7; }
.card-rose { background: #eee0dc; }
.card-number { font: .68rem var(--mono); letter-spacing: .08em; }
.card-icon { position: absolute; right: 1.5rem; top: 1.1rem; font-size: 1.5rem; }
.resource-card h3 { margin: 2.3rem 0 .5rem; font-size: clamp(1.5rem, 2.7vw, 2.3rem); letter-spacing: -.05em; }
.resource-card p { max-width: 390px; margin: 0; color: #565852; }
.card-cta { margin-top: auto; padding-top: 1.8rem; font-size: .85rem; font-weight: 600; }
.feature-section { display: grid; grid-template-columns: 1fr 1fr; gap: clamp(2rem, 8vw, 8rem); padding: clamp(4rem, 8vw, 7rem) clamp(1.25rem, 10vw, 10rem); background: #242622; color: #f8f7f3; }
.feature-section .eyebrow { color: #c5c8bd; }
.workflow { list-style: none; padding: 0; margin: 0; }
.workflow li { display: flex; gap: 1rem; padding: 1rem 0; border-bottom: 1px solid #4c4e47; font-size: 1.05rem; }
.workflow li span { color: var(--accent); font: .75rem var(--mono); padding-top: .35rem; }
.archive-note { max-width: 850px; padding: clamp(4rem, 8vw, 7rem) clamp(1.25rem, 7vw, 7rem); }
.archive-note p:not(.eyebrow) { max-width: 700px; color: var(--muted); }
.site-footer { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 1rem; padding: 2rem clamp(1.25rem, 5vw, 5rem); border-top: 1px solid var(--line); }
.site-footer p { color: var(--muted); font-size: .8rem; margin: 0; }
@media (max-width: 700px) {
  .site-header { align-items: flex-start; flex-direction: column; gap: .7rem; }
  nav { gap: 1rem; }
  .hero { min-height: 430px; }
  .hero-mark { right: -1rem; bottom: -1rem; opacity: .8; }
  .section-heading { align-items: flex-start; flex-direction: column; }
  .card-grid, .feature-section { grid-template-columns: 1fr; }
  .resource-card { min-height: 250px; }
  .site-footer { align-items: flex-start; flex-direction: column; }
}
@media (prefers-reduced-motion: reduce) {
  html { scroll-behavior: auto; }
  *, *::before, *::after { transition-duration: .01ms !important; }
}


</style>

<!-- wp:paragraph -->
<p><br>
<br>
<br>
  <meta charset="utf-8"><br>
  <meta name="viewport" content="width=device-width, initial-scale=1"><br>
  <meta name="description" content="Course materials, design briefs, tutorials, and creative resources from Nugget of Joy."><br>
  <title>Nugget of Joy — Communication, Art, Design &amp; Instruction</title>
  <link rel="stylesheet" href="assets/style.css">
<br>
<br>
  <a class="skip-link" href="#main">Skip to content</a></p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<header class="site-header">
    <a class="wordmark" href="/" aria-label="Nugget of Joy home">Nugget<span>of</span>Joy<span class="dot">.</span></a><p></p>
<nav aria-label="Main navigation">
      <a href="#learning">Learning</a><br>
      <a href="#design">UI/UX Design</a><br>
      <a href="#archive">Browse resources</a><br>
    </nav>
</header>
<!-- /wp:html -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<main id="main"><p></p>
<section class="hero">
<p class="eyebrow">COMMUNICATION · ART · DESIGN · INSTRUCTION</p>
<h1>A place to learn,<br><em>make, and explore.</em></h1>
<p class="intro">Course materials, design briefs, tutorials, and creative resources for curious makers and designers.</p>
<p>      <a class="text-link" href="#learning">Explore the resources <span aria-hidden="true">↘</span></a></p>
<div class="hero-mark" aria-hidden="true">N<span>o</span>J</div>
</section>
<section id="learning" class="resource-section">
<div class="section-heading">
<p class="eyebrow">START HERE</p>
<h2>Find what you need.</h2>
<p></p></div>
<div class="card-grid">
        <a class="resource-card card-sand" href="#design"><br>
          <span class="card-number">01 / DESIGN</span><br>
          <span class="card-icon" aria-hidden="true">↗</span><p></p>
<h3>UI/UX Design</h3>
<p>Design briefs, user flows, wireframes, prototypes, and interface resources.</p>
</a><p><a class="resource-card card-sand" href="#design">          <span class="card-cta">Explore design resources →</span><br>
        </a><br>
        <a class="resource-card card-blue" href="https://nuggetofjoy.com/ux-ui-design-brief-8-redesigning-the-spotify-app/"><br>
          <span class="card-number">02 / DESIGN BRIEF</span><br>
          <span class="card-icon" aria-hidden="true">↗</span></a></p><a class="resource-card card-blue" href="https://nuggetofjoy.com/ux-ui-design-brief-8-redesigning-the-spotify-app/">
<h3>Spotify App Redesign</h3>
<p>Open a UI/UX design brief and explore the redesign challenge.</p>
</a><p><a class="resource-card card-blue" href="https://nuggetofjoy.com/ux-ui-design-brief-8-redesigning-the-spotify-app/">          <span class="card-cta">Open the brief →</span><br>
        </a><br>
        <a class="resource-card card-green" href="#archive"><br>
          <span class="card-number">03 / LEARNING</span><br>
          <span class="card-icon" aria-hidden="true">↗</span></a></p><a class="resource-card card-green" href="#archive">
<h3>Tutorials &amp; Guides</h3>
<p>Practical references for digital media, visual communication, and making.</p>
</a><p><a class="resource-card card-green" href="#archive">          <span class="card-cta">Browse guides →</span><br>
        </a><br>
        <a class="resource-card card-rose" href="#archive"><br>
          <span class="card-number">04 / ARCHIVE</span><br>
          <span class="card-icon" aria-hidden="true">↗</span></a></p><a class="resource-card card-rose" href="#archive">
<h3>All Posts &amp; Resources</h3>
<p>Use the complete static-site archive to find older lessons and materials.</p>
</a><p><a class="resource-card card-rose" href="#archive">          <span class="card-cta">Browse the archive →</span><br>
        </a>
      </p></div>
</section>
<section id="design" class="feature-section">
<div>
<p class="eyebrow">DESIGN WORKFLOW</p>
<h2>From the first idea<br>to a working prototype.</h2>
<p></p></div>
<ol class="workflow">
<li><span>01</span> Understand the brief</li>
<li><span>02</span> Research users and needs</li>
<li><span>03</span> Map the user flow</li>
<li><span>04</span> Wireframe and prototype</li>
<li><span>05</span> Test, refine, and present</li>
</ol>
</section>
<section id="archive" class="archive-note">
<p class="eyebrow">THE RESOURCE LIBRARY</p>
<h2>One clear place to start.</h2>
<p>This homepage is a lightweight starting point. When the full WordPress export is restored, connect this section to the complete page and post index so students can browse the entire collection without relying on WordPress.</p>
<p>      <a class="text-link" href="https://nuggetofjoy.com/">Visit the current WordPress site <span aria-hidden="true">↗</span></a><br>
    </p></section>
<p>  </p></main>
<!-- /wp:html -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<footer class="site-footer">
    <a class="wordmark" href="/">Nugget<span>of</span>Joy<span class="dot">.</span></a><p></p>
<p>Communication, Art, Design &amp; Instruction</p>
<p>© 2026 Nugget of Joy</p>
</footer>
<!-- /wp:html -->

<!-- wp:paragraph {"style":{"css":"500\u0026family=DM+Sans:wght@400;500;600;700\u0026family=Playfair+Display:ital,wght@0,500;0,600;1,500;1,600\u0026display=swap');\n\n:root {\n  \u002d\u002dink: #20211f;\n  \u002d\u002dmuted: #666862;\n  \u002d\u002dpaper: #f8f7f3;\n  \u002d\u002dline: #deded6;\n  \u002d\u002daccent: #d3f36b;\n  \u002d\u002dmono: \u0022SFMono-Regular\u0022, Consolas, \u0022Liberation Mono\u0022, monospace;\n  \u002d\u002dsans: -apple-system, BlinkMacSystemFont, \u0022Segoe UI\u0022, Arial, sans-serif;\n  \u002d\u002dserif: Georgia, \u0022Times New Roman\u0022, serif;\n}\n* { box-sizing: border-box; }\nhtml { scroll-behavior: smooth; }\nbody { margin: 0; color: var(\u002d\u002dink); background: var(\u002d\u002dpaper); font-family: var(\u002d\u002dsans); line-height: 1.55; }\na { color: inherit; }\n.skip-link { position: absolute; top: -50px; left: 1rem; padding: .7rem 1rem; background: var(\u002d\u002daccent); z-index: 10; }\n.skip-link:focus { top: 1rem; }\n.site-header { min-height: 82px; display: flex; align-items: center; justify-content: space-between; gap: 2rem; padding: 1rem clamp(1.25rem, 5vw, 5rem); border-bottom: 1px solid var(\u002d\u002dline); }\n.wordmark { font-weight: 700; font-size: 1.35rem; letter-spacing: -.07em; text-decoration: none; white-space: nowrap; }\n.wordmark span:first-child { font-family: var(\u002d\u002dserif); font-style: italic; font-weight: 500; margin: 0 .1em; }\n.wordmark .dot { color: #7d9d1d; }\nnav { display: flex; flex-wrap: wrap; gap: clamp(1rem, 3vw, 2.5rem); }\nnav a { font-size: .86rem; text-decoration: none; }\nnav a:hover, .text-link:hover { text-decoration-thickness: 2px; text-underline-offset: 4px; text-decoration: underline; }\n.hero { position: relative; overflow: hidden; min-height: 470px; padding: clamp(4rem, 9vw, 8rem) clamp(1.25rem, 10vw, 10rem) 5rem; border-bottom: 1px solid var(\u002d\u002dline); }\n.eyebrow { font: 500 .7rem/1.4 var(\u002d\u002dmono); letter-spacing: .12em; text-transform: uppercase; color: var(\u002d\u002dmuted); }\n.hero h1 { position: relative; z-index: 1; max-width: 850px; margin: 1.2rem 0; font-size: clamp(3.2rem, 8vw, 7.2rem); line-height: .99; letter-spacing: -.075em; font-weight: 600; }\n.hero h1 em { font-family: var(\u002d\u002dserif); font-weight: 500; letter-spacing: -.065em; }\n.intro { max-width: 490px; font-size: 1.1rem; color: var(\u002d\u002dmuted); }\n.text-link { display: inline-block; margin-top: 1.4rem; font-weight: 600; text-decoration: none; border-bottom: 1px solid var(\u002d\u002dink); padding-bottom: .3rem; }\n.hero-mark { position: absolute; right: 7%; bottom: -3.5rem; color: #eeede6; font-size: clamp(10rem, 26vw, 25rem); line-height: 1; letter-spacing: -.13em; font-weight: 700; pointer-events: none; }\n.hero-mark span { font-family: var(\u002d\u002dserif); font-style: italic; }\n.resource-section { padding: clamp(4rem, 8vw, 7rem) clamp(1.25rem, 7vw, 7rem); }\n.section-heading { display: flex; align-items: end; justify-content: space-between; gap: 2rem; margin-bottom: 2rem; }\nh2 { margin: .4rem 0 0; font-size: clamp(2.1rem, 4vw, 3.7rem); line-height: 1.05; letter-spacing: -.06em; }\n.card-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 1rem; }\n.resource-card { min-height: 280px; position: relative; display: flex; flex-direction: column; align-items: flex-start; padding: clamp(1.4rem, 3vw, 2.5rem); text-decoration: none; transition: transform .18s ease; }\n.resource-card:hover { transform: translateY(-4px); }\n.card-sand { background: #ece7db; }\n.card-blue { background: #dce8ee; }\n.card-green { background: #e1e8d7; }\n.card-rose { background: #eee0dc; }\n.card-number { font: .68rem var(\u002d\u002dmono); letter-spacing: .08em; }\n.card-icon { position: absolute; right: 1.5rem; top: 1.1rem; font-size: 1.5rem; }\n.resource-card h3 { margin: 2.3rem 0 .5rem; font-size: clamp(1.5rem, 2.7vw, 2.3rem); letter-spacing: -.05em; }\n.resource-card p { max-width: 390px; margin: 0; color: #565852; }\n.card-cta { margin-top: auto; padding-top: 1.8rem; font-size: .85rem; font-weight: 600; }\n.feature-section { display: grid; grid-template-columns: 1fr 1fr; gap: clamp(2rem, 8vw, 8rem); padding: clamp(4rem, 8vw, 7rem) clamp(1.25rem, 10vw, 10rem); background: #242622; color: #f8f7f3; }\n.feature-section .eyebrow { color: #c5c8bd; }\n.workflow { list-style: none; padding: 0; margin: 0; }\n.workflow li { display: flex; gap: 1rem; padding: 1rem 0; border-bottom: 1px solid #4c4e47; font-size: 1.05rem; }\n.workflow li span { color: var(\u002d\u002daccent); font: .75rem var(\u002d\u002dmono); padding-top: .35rem; }\n.archive-note { max-width: 850px; padding: clamp(4rem, 8vw, 7rem) clamp(1.25rem, 7vw, 7rem); }\n.archive-note p:not(.eyebrow) { max-width: 700px; color: var(\u002d\u002dmuted); }\n.site-footer { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 1rem; padding: 2rem clamp(1.25rem, 5vw, 5rem); border-top: 1px solid var(\u002d\u002dline); }\n.site-footer p { color: var(\u002d\u002dmuted); font-size: .8rem; margin: 0; }\n@media (max-width: 700px) {\n  .site-header { align-items: flex-start; flex-direction: column; gap: .7rem; }\n  nav { gap: 1rem; }\n  .hero { min-height: 430px; }\n  .hero-mark { right: -1rem; bottom: -1rem; opacity: .8; }\n  .section-heading { align-items: flex-start; flex-direction: column; }\n  .card-grid, .feature-section { grid-template-columns: 1fr; }\n  .resource-card { min-height: 250px; }\n  .site-footer { align-items: flex-start; flex-direction: column; }\n}\n@media (prefers-reduced-motion: reduce) {\n  html { scroll-behavior: auto; }\n  *, *::before, *::after { transition-duration: .01ms !important; }\n}\n"}} -->
<p class="has-custom-css"><br>
</p>
<!-- /wp:paragraph -->
