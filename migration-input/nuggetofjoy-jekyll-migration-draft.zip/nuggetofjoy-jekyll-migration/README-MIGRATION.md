# NuggetOfJoy Jekyll migration draft

This package contains a first-pass conversion of published WordPress posts and pages to Jekyll Markdown files.

- `_posts/`: published WordPress posts; the original HTML body is retained rather than flattened.
- `_pages/`: published WordPress pages.
- `reports/content-manifest.csv`: original URLs, target files, categories, tags, and content sizes.
- `reports/excluded-drafts-private.csv`: drafts/private posts intentionally excluded from the public content set.
- `reports/media-urls.txt`: 4142 unique media URLs detected in published post/page bodies.
- `reports/category-counts.csv` and `reports/tag-counts.csv`: taxonomy inventory.

Important caveats:
1. This is a content-conversion draft, not yet a production-ready site. Review paths and HTML after importing into the repository.
2. The WordPress XML export contains attachment metadata and URLs, not the actual binary media files. Some media URLs point to remote WordPress/S3 storage and need a separate asset migration or link audit.
3. Existing WordPress URLs are retained as Jekyll `permalink` values where present.
4. Draft/private posts are not included in `_posts/` or `_pages/` to avoid publishing them accidentally.
5. WordPress shortcodes and plugin-specific markup are preserved verbatim and may require adaptation if the associated plugin behavior is not available on the static site.
