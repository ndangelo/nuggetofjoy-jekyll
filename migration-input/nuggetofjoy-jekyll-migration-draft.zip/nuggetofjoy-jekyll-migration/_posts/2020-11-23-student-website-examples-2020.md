---
title: "Student Website Examples 2020"
date: "2020-11-23 13:45:23"
layout: post
permalink: "/student-website-examples-2020/"
categories: ["projects"]
tags: []
wordpress_id: "57766"
---

<!-- wp:paragraph -->
<p><strong>Roxine Kee</strong></p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":20671} -->
<div class="wp-block-image"><figure class="aligncenter"><img src="http://nuggetofjoy.com/wp-content/uploads/Roxine-Kee-website-image-2020-9.jpg" alt="Roxine Kee's personal website" class="wp-image-20671"/></figure></div>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p><strong>Elizabeth Lundin</strong></p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":20072} -->
<div class="wp-block-image"><figure class="aligncenter"><img src="http://nuggetofjoy.com/wp-content/uploads/Elizabeth_Lundin-2019-4.jpg" alt="Elizabeth Lundin's personal website" class="wp-image-20072"/></figure></div>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p>A former writer for College Info Geek, Elizabeth is a great freelance writer with a website to showcase her work and tell her story. Here’s what her site can teach you:</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Taha Khan</strong></p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":20673} -->
<div class="wp-block-image"><figure class="aligncenter"><img src="http://nuggetofjoy.com/wp-content/uploads/Taha-Khan-website-image-2020-4.jpg" alt="Taha Khan's personal website" class="wp-image-20673"/></figure></div>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p>Taha Khan does a lot of different things, including speaking, directing, comedy, and film production. Here’s what you can learn from his site:</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 id="personal-branding-website-examples"><a href="https://collegeinfogeek.com/personal-website-examples/#personal-branding-website-examples"></a>Personal Branding Website Examples</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>I’ve already touched on&nbsp;<a href="https://collegeinfogeek.com/personal-brand/">personal branding</a>&nbsp;a bit in this post, but next up I want to look at some websites that are&nbsp;<em>killing it&nbsp;</em>with how they showcase the site owner’s personality and style.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Andrew Huang</strong></p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":20080} -->
<div class="wp-block-image"><figure class="aligncenter"><img src="http://nuggetofjoy.com/wp-content/uploads/Andrew_Huang-2019-4.jpg" alt="Andrew Huang's personal website" class="wp-image-20080"/></figure></div>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p>Andrew Huang is a musician, producer, and YouTuber. I’ve been following his YouTube channel longer (and more consistently) than any other (except for the CIG YouTube channel, of course). His videos are creative, funny, and always impressive. Here’s what his site can teach us:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul><li><strong>Clarissa Rodriguez</strong></li></ul>
<!-- /wp:list -->

<!-- wp:image {"align":"center","id":20711} -->
<div class="wp-block-image"><figure class="aligncenter"><img src="http://nuggetofjoy.com/wp-content/uploads/Clarissa-Rodriguez-website-image-2020-4.jpg" alt="Clarissa Rodriguez website home page" class="wp-image-20711"/></figure></div>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p>We love to showcase the work of other people who are helping students succeed in college, and Clarissa Rodriguez is one of those people. She offers an online course on study skills, as well as personalized study consultations. You can learn more about her inspiring story of going from failing multiple classes to graduating college with honors in&nbsp;<a href="https://collegeinfogeek.com/clarissa-rodriguez/">Episode 68 of the College Info Geek Podcast</a>.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Looking at her site, you can also learn some important lessons about personal branding:</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Nasos Papadopoulos</strong></p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":20710} -->
<div class="wp-block-image"><figure class="aligncenter"><img src="http://nuggetofjoy.com/wp-content/uploads/Nasos-Papdopoulos-updated-2020-4.jpg" alt="Nasos Papadopoulos website About page" class="wp-image-20710"/></figure></div>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p>Nasos Papadopoulos is the founder of MetaLearn, of method and series of courses that teaches you how to learn things on your own. The site also has superb branding:</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Matthew Barby</strong></p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":20085} -->
<div class="wp-block-image"><figure class="aligncenter"><img src="http://nuggetofjoy.com/wp-content/uploads/Matthew_Barby-2019-4.jpg" alt="Matthew Barby's personal website" class="wp-image-20085"/></figure></div>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p>In addition to writing and editing blog posts for this site, I also work on SEO (Search Engine Optimization). Briefly, it’s the field of getting your website to show up as high as possible in Google search results (or technically other search engines, but in practice that tends to be Google as its the dominant player).</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Matthew Barby’s site has been my main guide as I’ve been teaching myself SEO. Additionally, the site is a masterpiece of personal branding:</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Isa Adney</strong></p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":20086} -->
<div class="wp-block-image"><figure class="aligncenter"><img src="http://nuggetofjoy.com/wp-content/uploads/Isa_Adney-2019-4.jpg" alt="Isa Adney's personal website" class="wp-image-20086"/></figure></div>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p>Isa Adney is a writer and webinar producer for ConvertKit, as well as author of the forthcoming&nbsp;<em>The Little Book of Big Dreams: True Stories of Dreams Come True.&nbsp;</em>She appeared in&nbsp;<a href="https://collegeinfogeek.com/isa-adney/">Episode 46 of the College Info Geek Podcast</a>, where she discussed how to make community college an ivy league experience. Here’s what her site can teach you about branding:</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Tasha Meys</strong></p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":20713} -->
<div class="wp-block-image"><figure class="aligncenter"><img src="http://nuggetofjoy.com/wp-content/uploads/Tasha-Meys-personal-website-2020-4.jpg" alt="Tasha Meys personal website" class="wp-image-20713"/></figure></div>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p>Tasha Meys is an artist, photographer, social media consultant, and world traveler. Her site showcases all of this work with a brand that is colorful and exciting. Here’s what her site can teach you about branding:</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Andrew Rea</strong></p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":20708} -->
<div class="wp-block-image"><figure class="aligncenter"><img src="http://nuggetofjoy.com/wp-content/uploads/Andrew-Rea-image-2020-cropped-4.jpg" alt="Andrew Rea website About page" class="wp-image-20708"/></figure></div>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p>Andrew Rea is a chef, filmmaker, and creator of the popular YouTube cooking show Binging With Babish. While he rarely uses his real name in his YouTube videos, I love the About page on his website. Here’s what his website can teach you about personal branding:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul><li><strong>Clever website bio</strong>&nbsp;– Andrew’s bio describes him as “one part chef, one part filmmaker, and a generous dash of irreverent YouTube personality.” Written as a recipe, this description fits right in with Andrew’s cooking show brand. The photo is also perfect, showing someone who’s fun, casual, and cool.</li></ul>
<!-- /wp:list -->

<!-- wp:heading -->
<h2 id="website-design-examples"><a href="https://collegeinfogeek.com/personal-website-examples/#website-design-examples"></a>Website Design Examples</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Next, we move to the design portion of this guide. Many of these sites showcase the work of graphic, product, or UX designers; unsurprisingly, they are well-designed. But others showcase the work of authors, photographers, and thought leaders, showing that you don’t have to be a designer to have a compelling site design. All of them serve as inspiration.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Edna Cerrillos</strong></p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":20714} -->
<div class="wp-block-image"><figure class="aligncenter"><img src="http://nuggetofjoy.com/wp-content/uploads/Edna-Cerrillos-personal-website-2020-4.jpg" alt="Edna Cerrillos personal website" class="wp-image-20714"/></figure></div>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p>As you can clearly see from the first glance, Edna Cerrillos is a designer (a product and UX/UI designer to be more precise). As you would expect from a designer’s personal website, Edna’s site can teach us some important design lessons.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Roxane Gay</strong></p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":20090} -->
<div class="wp-block-image"><figure class="aligncenter"><img src="http://nuggetofjoy.com/wp-content/uploads/Roxane_Gay-2019-4.jpg" alt="Roxane Gay's personal website" class="wp-image-20090"/></figure></div>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p>Roxane Gay is an author, essayist, and speaker. She’s one of my (other) favorite contemporary authors, so I was delighted to see that her site is also an excellent example of design:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul><li><strong>Minimalism with personality</strong>&nbsp;– The image you see above is exactly what appears when you visit Roxane’s site. There are no additional menus or text–just the one footer menu with links to everything a visitor would want to know, all backed by a pleasing geometric design. The “one n” is also a nice branding touch.</li></ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p><strong>Charli Marie</strong></p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":20715} -->
<div class="wp-block-image"><figure class="aligncenter"><img src="http://nuggetofjoy.com/wp-content/uploads/Charli-Marie-site-image-2020-4.jpg" alt="Charli Marie personal website image" class="wp-image-20715"/></figure></div>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p>Charli Marie is a designer, speaker, and self-proclaimed “side project addict” who currently works for email marketing software company ConvertKit. The site is a design masterpiece:</p>
<!-- /wp:paragraph -->
