---
title: "Perspective and POV"
date: "2020-02-04 17:00:54"
layout: post
permalink: "/perspective-and-pov/"
categories: ["gn-basic-drawing"]
tags: []
wordpress_id: "52774"
---

<!-- wp:paragraph {"align":"center","textColor":"luminous-vivid-orange","fontSize":"medium"} -->
<p class="has-text-color has-text-align-center has-medium-font-size has-luminous-vivid-orange-color"><strong>Determine a Point of View </strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Where are you standing in relation to the objects you see? What is your point of view? Do you see them in full view? Do you see things from a side view or at an angle? Do you see anything in a foreshortened view?</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Read Light and Shadow Is light falling on the objects? Is it falling from one side? Top? Bottom? Are there shadows on the objects? Are there cast shadows on the tabletop or floor? Read Color Which colors (hues, values, and chromatic intensities) do you see? Are the colors warm or cool?</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","fontSize":"medium"} -->
<p class="has-text-align-center has-medium-font-size"><strong><span class="tadv-color" style="color: #ff6900;">Perspective</span></strong></p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":52413} -->
<div class="wp-block-image"><figure class="aligncenter"><img src="http://nuggetofjoy.com/wp-content/uploads/2019-08-23-12_44_53-Nicholass-Kindle-for-PC-4-The-Guided-Sketchbook-That-Teaches-You-How-To-DRAW.png" alt="" class="wp-image-52413"/></figure></div>
<!-- /wp:image -->

<!-- wp:tadv/classic-paragraph -->
<div class="wp-block-image"> </div>
<!-- /wp:tadv/classic-paragraph -->

<!-- wp:more -->
<!--more-->
<!-- /wp:more -->

<!-- wp:paragraph -->
<p>Perspective is based on the idea that diagonals moving toward a point on the horizon, called the vanishing point, will imitate the recession of space into the distance and create the illusion of spatial depth. Italian Renaissance artist and architect Filippo Brunelleschi, who had reproduced a three-dimensional object in two dimensions, is credited with inventing perspective. Most artists and designers create the illusion of spatial depth with less formal methods, by “eyeballing” what they see or imagine rather than using official perspectival drawing methods. We’ll begin with learning to draw what we see by eyeballing, by astute observations.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Essentially, when your intent is to create a pictorial space that imitates what you see in the world, you need to understand this: That small sketchbook page you hold in your hands becomes the framing unit of an illusion of three-dimensional space. The page becomes a field of vision. If you want figures to look like they are standing on the ground, you must think about creating a tilted floor plane for them to stand on. If you want pictorial space to look like it is receding into the distance, you must think about the sizes of elements—the scale of things in relation to one another and to the page.</p>
<!-- /wp:paragraph -->

<p>&nbsp;</p>

<!-- wp:paragraph {"align":"center","fontSize":"medium"} -->
<p class="has-text-align-center has-medium-font-size"><strong><span class="tadv-color" style="color: #ff6900;">Flat or with Depth?</span></strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>You can conjure the illusion of three-dimensional space in a drawing, denying the characteristic flatness of the paper or screen. That illusion of space can be shallow, deep, ambiguous, or even fractured (think Cubism). Or you can maintain the flatness of the page in a drawing. It’s completely up to you. Shading and tone create the illusion of volume, too.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","fontSize":"medium"} -->
<p class="has-text-align-center has-medium-font-size"><strong><span class="tadv-color" style="color: #ff6900;">Exercises</span></strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Draw a diagonal within this rectangle or on a blank page, but don’t draw the diagonal all the way from corner to corner. Notice that the diagonal looks like it is receding into the graphic space. Just one diagonal can hint at the illusion of three-dimensional space.</p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":52414} -->
<div class="wp-block-image"><figure class="aligncenter"><img src="http://nuggetofjoy.com/wp-content/uploads/image13.png" alt="" class="wp-image-52414"/></figure></div>
<!-- /wp:image -->

<!-- wp:tadv/classic-paragraph -->
<div class="wp-block-image"> </div>
<!-- /wp:tadv/classic-paragraph -->

<!-- wp:paragraph -->
<p>Draw a simple room space on this page, like the one you see in the diagram. Add a few objects, such as a cube, a chair, or a figure, to create the illusion of three-dimensional forms in space.</p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":52415} -->
<div class="wp-block-image"><figure class="aligncenter"><img src="http://nuggetofjoy.com/wp-content/uploads/image14.png" alt="" class="wp-image-52415"/></figure></div>
<!-- /wp:image -->

<!-- wp:tadv/classic-paragraph -->
<div class="wp-block-image"> </div>
<!-- /wp:tadv/classic-paragraph -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size"><p class="has-small-font-size"><em>Landa, Robin. The Guided Sketchbook That Teaches You How To DRAW! (p. 8). Pearson Education. Kindle Edition.</em></p>
<p>&nbsp;</p>
<p><!--nextpage--></p>
<p>&nbsp;</p></p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":52754} -->
<div class="wp-block-image"><figure class="aligncenter"><img src="http://nuggetofjoy.com/wp-content/uploads/2019-08-27-18_26_12-GN_-BASIC-DRAWING-Presentation-Google-Slides.png" alt="" class="wp-image-52754"/></figure></div>
<!-- /wp:image -->

<!-- wp:image {"align":"center","id":52755} -->
<div class="wp-block-image"><figure class="aligncenter"><img src="http://nuggetofjoy.com/wp-content/uploads/2019-08-27-18_26_44-GN_-BASIC-DRAWING-Presentation-Google-Slides.png" alt="" class="wp-image-52755"/></figure></div>
<!-- /wp:image -->

<!-- wp:image {"align":"center","id":52756} -->
<div class="wp-block-image"><figure class="aligncenter"><img src="http://nuggetofjoy.com/wp-content/uploads/2019-08-27-18_25_45-GN_-BASIC-DRAWING-Presentation-Google-Slides.png" alt="" class="wp-image-52756"/></figure></div>
<!-- /wp:image -->

<!-- wp:image {"align":"center","id":52757} -->
<div class="wp-block-image"><figure class="aligncenter"><img src="http://nuggetofjoy.com/wp-content/uploads/2019-08-27-18_27_07-GN_-BASIC-DRAWING-Presentation-Google-Slides.png" alt="" class="wp-image-52757"/></figure></div>
<!-- /wp:image -->

<!-- wp:heading -->
<h2>&nbsp;</h2>
<!-- /wp:heading -->

<!-- wp:image {"align":"center","id":52975,"linkDestination":"media"} -->
<div class="wp-block-image"><figure class="aligncenter"><a href="http://nuggetofjoy.com/wp-content/uploads/2aa3208ba134fecc869be1d9b413aa70-line-sketch-perspective-drawing.jpg"><img src="http://nuggetofjoy.com/wp-content/uploads/2aa3208ba134fecc869be1d9b413aa70-line-sketch-perspective-drawing.jpg" alt="" class="wp-image-52975"/></a><figcaption>Three-point perspective</figcaption></figure></div>
<!-- /wp:image -->

<!-- wp:image {"align":"center","id":53031,"linkDestination":"media"} -->
<div class="wp-block-image"><figure class="aligncenter"><a href="http://nuggetofjoy.com/wp-content/uploads/a166a4cfc1f85bd9c3d1260e860180c2.jpg"><img src="http://nuggetofjoy.com/wp-content/uploads/a166a4cfc1f85bd9c3d1260e860180c2.jpg" alt="" class="wp-image-53031"/></a><figcaption><a href="https://www.pinterest.co.kr/pin/679621400000592762/?nic=1">https://www.pinterest.co.kr/pin/679621400000592762/?nic=1</a></figcaption></figure></div>
<!-- /wp:image -->

<!-- wp:image {"id":53032,"linkDestination":"media"} -->
<figure class="wp-block-image"><a href="http://nuggetofjoy.com/wp-content/uploads/5c1fe09522596710bed48ef3a34bcdf2.jpg"><img src="http://nuggetofjoy.com/wp-content/uploads/5c1fe09522596710bed48ef3a34bcdf2.jpg" alt="" class="wp-image-53032"/></a><figcaption><a href="https://www.pinterest.co.kr/pin/679621400000592762/?nic=1">https://www.pinterest.co.kr/pin/679621400000592762/?nic=1</a></figcaption></figure>
<!-- /wp:image -->

<!-- wp:image {"align":"center","id":52976,"linkDestination":"media"} -->
<div class="wp-block-image"><figure class="aligncenter"><a href="http://nuggetofjoy.com/wp-content/uploads/2pt-perspective1.png"><img src="http://nuggetofjoy.com/wp-content/uploads/2pt-perspective1.png" alt="" class="wp-image-52976"/></a></figure></div>
<!-- /wp:image -->

<!-- wp:image {"align":"center","id":52981,"linkDestination":"media"} -->
<div class="wp-block-image"><figure class="aligncenter"><a href="http://nuggetofjoy.com/wp-content/uploads/702aa36c6e464eaf66517d11b88ffbfd.jpg"><img src="http://nuggetofjoy.com/wp-content/uploads/702aa36c6e464eaf66517d11b88ffbfd.jpg" alt="" class="wp-image-52981"/></a><figcaption>Legos: Two Point Perspective</figcaption></figure></div>
<!-- /wp:image -->

<!-- wp:image {"align":"center","id":52982,"linkDestination":"media"} -->
<div class="wp-block-image"><figure class="aligncenter"><a href="http://nuggetofjoy.com/wp-content/uploads/1f00d79851c049f830510c40f5285a9b.jpg"><img src="http://nuggetofjoy.com/wp-content/uploads/1f00d79851c049f830510c40f5285a9b.jpg" alt="" class="wp-image-52982"/></a></figure></div>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p>Utilizing your knowledge of one, two, and three-point perspective, draw a "construct" using only "cuboids" or simply box-shaped objects. Make "thumbnail" sketches to get an idea of what your composition will be like. Use an entire page in your sketchbook when you are ready to create the final drawing. Due: TBA.</p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":52983,"linkDestination":"media"} -->
<div class="wp-block-image"><figure class="aligncenter"><a href="http://nuggetofjoy.com/wp-content/uploads/fa8bd21dd2f2f92fd69b37114e3f3805.jpg"><img src="http://nuggetofjoy.com/wp-content/uploads/fa8bd21dd2f2f92fd69b37114e3f3805.jpg" alt="" class="wp-image-52983"/></a><figcaption>Abstract "Block" Composition using two-point perspective<br><br><br></figcaption></figure></div>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p><strong> FYI </strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>This will be your first assignment that culminates in a large final drawing. I'm still looking for an appropriate pad with quality paper, medium grain, and is economical.</p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":53027,"linkDestination":"media"} -->
<div class="wp-block-image"><figure class="aligncenter"><a href="http://nuggetofjoy.com/wp-content/uploads/22205566f2fe3a56a757b17c9f6836eb.jpg"><img src="http://nuggetofjoy.com/wp-content/uploads/22205566f2fe3a56a757b17c9f6836eb-551x1024.jpg" alt="" class="wp-image-53027"/></a><figcaption><a href="http://mseatonsart.blogspot.com/2014/03/space-museums-2-3-point-perspective.html">http://mseatonsart.blogspot.com/2014/03/space-museums-2-3-point-perspective.html</a></figcaption></figure></div>
<!-- /wp:image -->

<!-- wp:image {"align":"center","id":53028,"linkDestination":"media"} -->
<div class="wp-block-image"><figure class="aligncenter"><a href="http://nuggetofjoy.com/wp-content/uploads/IMG_0637.jpg"><img src="http://nuggetofjoy.com/wp-content/uploads/IMG_0637-657x1024.jpg" alt="" class="wp-image-53028"/></a><figcaption><a href="http://mseatonsart.blogspot.com/2014/03/space-museums-2-3-point-perspective.html">http://mseatonsart.blogspot.com/2014/03/space-museums-2-3-point-perspective.html</a></figcaption></figure></div>
<!-- /wp:image -->

<!-- wp:image {"align":"center","id":53029,"linkDestination":"media"} -->
<div class="wp-block-image"><figure class="aligncenter"><a href="http://nuggetofjoy.com/wp-content/uploads/IMG_0641.jpg"><img src="http://nuggetofjoy.com/wp-content/uploads/IMG_0641-696x1024.jpg" alt="" class="wp-image-53029"/></a><figcaption><a href="http://mseatonsart.blogspot.com/2014/03/space-museums-2-3-point-perspective.html">http://mseatonsart.blogspot.com/2014/03/space-museums-2-3-point-perspective.html</a></figcaption></figure></div>
<!-- /wp:image -->

<!-- wp:image {"align":"center","id":53030,"linkDestination":"media"} -->
<div class="wp-block-image"><figure class="aligncenter"><a href="http://nuggetofjoy.com/wp-content/uploads/IMG_0648.jpg"><img src="http://nuggetofjoy.com/wp-content/uploads/IMG_0648-644x1024.jpg" alt="" class="wp-image-53030"/></a><figcaption><a href="http://mseatonsart.blogspot.com/2014/03/space-museums-2-3-point-perspective.html">http://mseatonsart.blogspot.com/2014/03/space-museums-2-3-point-perspective.html</a></figcaption></figure></div>
<!-- /wp:image -->

<!-- wp:image {"id":53033,"linkDestination":"media"} -->
<figure class="wp-block-image"><a href="http://nuggetofjoy.com/wp-content/uploads/sea_shell_house_by_radu26_d6itoc7-pre.jpg"><img src="http://nuggetofjoy.com/wp-content/uploads/sea_shell_house_by_radu26_d6itoc7-pre.jpg" alt="" class="wp-image-53033"/></a><figcaption><a href="https://www.deviantart.com/radu26/art/Sea-Shell-House-394414711">https://www.deviantart.com/radu26/art/Sea-Shell-House-394414711</a></figcaption></figure>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p>&nbsp;</p>
<!-- /wp:paragraph -->

<p><!--EndFragment--></p>
